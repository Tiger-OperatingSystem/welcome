#!/usr/bin/env bash

bigbashview -t gtk -w fixed -s 900x620 -i icons/logo.png -n 'Bem-vindo ao TigerOS' index.sh.htm